#include <cs50.h>
#include <stdio.h>

const int TOTAL = 3;

int main(void)
{
    // int scores[3];
    // scores[0] = 72;
    // scores[1] = 73;
    // scores[2] = 33;
    
    // printf("Average: %f\n", (score1 + score2 +score3) / 3);

    int total = get_int("Total number of scores: ");
    
    int scores[TOTAL];
    for (it i = 0; i < TOTA; i++)
    {
        scores[i] = get_int("Score: ")
    }
    
    printf("Average: %f\n, scores[0]")
} 