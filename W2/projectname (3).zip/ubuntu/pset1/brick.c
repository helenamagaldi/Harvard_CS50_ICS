#include <stdio.h>

int main(void)
{
    char c = '#';
    
    printf("%i\n", c);
}