int main(void) {
  int space = 1;
  space = space--;
}
