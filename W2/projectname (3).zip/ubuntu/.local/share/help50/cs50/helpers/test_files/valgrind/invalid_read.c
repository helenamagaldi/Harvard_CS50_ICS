int main(void) {
  int x[1];
  x[1700]++;
}
