#include <math.h>

int main(void) {
  round(1.7);
}
