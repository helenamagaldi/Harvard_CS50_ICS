#include <math.h>

int round(int n);

int main(void) {
}
