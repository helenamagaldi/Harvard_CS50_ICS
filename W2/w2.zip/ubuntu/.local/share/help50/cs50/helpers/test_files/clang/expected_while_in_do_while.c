int main(void) {
  do {

  }
}
