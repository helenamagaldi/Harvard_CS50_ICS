int square(28);

int main(void) {

}
