#include <stdio.h>
#include <math.h>

int main(void) {
  int x = round(2.4));
  printf("%d\n", x);
}
