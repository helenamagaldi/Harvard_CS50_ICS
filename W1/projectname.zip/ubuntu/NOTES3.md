get_char

get_double

get_float

get_int

get_long

get_string

%c

%f

%i

%li

%s