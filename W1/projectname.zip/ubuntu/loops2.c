#include <cs50.h>
#include <stdio.h>

int main(void)
{
for (int i = 0; i < 50 ; i++ )
{
    printf("hello, world\n");
}
}