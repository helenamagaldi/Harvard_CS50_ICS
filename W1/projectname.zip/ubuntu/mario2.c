#include <cs50.h>
#include <stdio.h>

int main(void)
{
    // printf("###\n");

    for (int i = 0; i < 3; i++)
    {
        for int (int j=0; j<3; j++)
        {
            printf("x");
        }
        printf("\n");
    }
}