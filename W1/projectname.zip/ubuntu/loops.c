#include <cs50.h>
#include <stdio.h>

int main(void)
{
int i = 0;
while (i<50)
{
    printf("world\n");
    i++;
    // also works with i++
    
}
}