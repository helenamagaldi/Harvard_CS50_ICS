int main(void) {
  for(int i == 0; i < 2; i++);
}
