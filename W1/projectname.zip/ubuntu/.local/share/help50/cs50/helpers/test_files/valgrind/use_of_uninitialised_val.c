int main(void) {
  int x;
  int foo = x + 2;
  int y[10];
  y[foo] = 17;
}
