#include <stdio.h>

int main(void) {
  printf("%s \ n", "hi");
}
