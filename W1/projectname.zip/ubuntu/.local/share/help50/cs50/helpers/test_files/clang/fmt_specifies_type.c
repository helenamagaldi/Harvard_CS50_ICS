#include <stdio.h>

int main(void) {
  printf("%d\n", "hello!");
}
