#include <cs50.h>

int main(void) {
  float f;
  f = get_float;
}
