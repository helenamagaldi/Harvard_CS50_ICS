#include <stdio.h>

// Prototype: adianta a funcao que esta abaixo da main
void meow();

int main(void)
{
 for (int i = 0; i < 3; i++)
 {
    //  printf("meow\n");
    meow();
 }
}

// void meow(void)
// void meow(int n)
// {
//     for (int i = 0; i < n; i++)
//     {
//         printf("meow\n");
//     }
// }
