cd
cp
ls
mkd8ir
mv
rm
rmdir
...